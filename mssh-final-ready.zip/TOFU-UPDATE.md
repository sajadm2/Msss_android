# Simple SSH login update
Manual fingerprint entry replaced by first-use host key discovery and explicit confirmation.
Discovery rejects the SSH host key before authentication; no password is provided.
Confirmed SHA256 pins are stored per host/port in app-private preferences. Subsequent connections enforce the pin with StrictHostKeyChecking=yes. Changed keys are not automatically accepted.
First-use trust is not independently authenticated and can be vulnerable to interception. No automatic pin reset is provided.
Passwords remain memory-only. UDP/V2Ray support was NOT added.
Build and device tests have not been run in this environment (Android SDK unavailable).
