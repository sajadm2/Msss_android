package com.mousavi.vpn

import android.content.Context
import android.util.Base64
import com.jcraft.jsch.*
import java.security.MessageDigest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** TOFU: discovery deliberately rejects the key before SSH authentication. */
object HostTrust {
    private fun endpoint(p: ServerProfile): String = Base64.encodeToString(
        MessageDigest.getInstance("SHA-256").digest("${p.host.trim().lowercase()}:${p.port}".toByteArray(Charsets.UTF_8)),
        Base64.NO_WRAP)
    fun saved(context: Context, p: ServerProfile): String? =
        context.getSharedPreferences("ssh_host_pins", Context.MODE_PRIVATE).getString(endpoint(p), null)
    fun save(context: Context, p: ServerProfile, fingerprint: String): Boolean =
        context.getSharedPreferences("ssh_host_pins", Context.MODE_PRIVATE).edit()
            .putString(endpoint(p), fingerprint).commit()

    suspend fun discover(p: ServerProfile): String = withContext(Dispatchers.IO) {
        var found: String? = null
        val jsch = JSch()
        jsch.setHostKeyRepository(object : HostKeyRepository {
            override fun check(host: String?, key: ByteArray?): Int {
                if (key != null) found = "SHA256:" + Base64.encodeToString(
                    MessageDigest.getInstance("SHA-256").digest(key), Base64.NO_WRAP or Base64.NO_PADDING)
                return HostKeyRepository.NOT_INCLUDED
            }
            override fun add(hostkey: HostKey?, ui: UserInfo?) = Unit
            override fun remove(host: String?, type: String?) = Unit
            override fun remove(host: String?, type: String?, key: ByteArray?) = Unit
            override fun getKnownHostsRepositoryID(): String = "mssh discovery only"
            override fun getHostKey(): Array<HostKey> = emptyArray()
            override fun getHostKey(host: String?, type: String?): Array<HostKey> = emptyArray()
        })
        val session = jsch.getSession(p.username, p.host, p.port)
        session.setConfig("StrictHostKeyChecking", "yes")
        session.timeout = 10000
        try { session.connect(10000) } catch (_: JSchException) {
            // Expected rejection: no password is supplied or sent during discovery.
        } finally { session.disconnect() }
        found ?: throw IllegalStateException("دریافت کلید سرور ممکن نشد؛ آدرس، پورت و اینترنت را بررسی کنید.")
    }
}
