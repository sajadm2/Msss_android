package hev.htproxy

/** Matches the upstream JNI registration; do not rename without changing native code. */
class TProxyService {
    companion object { init { System.loadLibrary("hev-socks5-tunnel") } }
    external fun TProxyStartService(path: String, fd: Int): Boolean
    external fun TProxyStopService(): Boolean
    external fun TProxyIsRunning(): Boolean
    external fun TProxyGetStats(): LongArray
}
